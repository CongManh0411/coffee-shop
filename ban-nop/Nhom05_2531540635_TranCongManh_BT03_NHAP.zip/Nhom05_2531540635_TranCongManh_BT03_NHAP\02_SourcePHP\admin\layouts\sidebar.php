<aside class="sidebar">
    <!-- Logo + tên quán -->
    <div class="sidebar-shop">
        <img src="<?= e($assetPrefix) ?>images/images.jpg" alt="Coffee Logo" class="shop-logo" id="shopLogo">
    </div>
 
    <!-- User đang đăng nhập + chức vụ — nội dung "Tên"/"Chức vụ" chỉ là mặc định,
         sẽ được script.js (UserAPI) ghi đè bằng dữ liệu thật khi trang tải xong. -->
    <div class="sidebar-user">
        <div class="user-name" id="userName">Tên</div>
        <div class="user-role" id="userRole">Chức vụ</div>
    </div>
 
    <div class="sidebar-nav">
        <div class="sidebar-menu">
            <div class="sidebar-menu" id="sidebarMenu"></div>
        </div>
    </div>
 
    <!-- Đăng xuất — luôn nằm ở đáy sidebar nhờ margin-top:auto trong CSS -->
    <div class="sidebar-footer">
        <button type="button" class="btn-logout" id="btnLogout">
            <i class="ri-logout-box-r-line"></i>
            Đăng xuất
        </button>
    </div>
</aside>
